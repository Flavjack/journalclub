**Journal Club as a Teaching-Learning Strategy: A Case for Plant Genetics Lectures During the COVID-19 Pandemic**

Flavio Lozano-Isla^a, c\*^; Elizabeth Heros-Aguilar^a^; Andres Casas-Diaz^b^

^a^ *Departamento Académico de Fitotecnia, Facultad de Agronomía, Universidad Nacional Agraria La Molina, Lima, Perú.*

^b^ *Departamento Académico de Horticultura, Facultad de Agronomía, Universidad Nacional Agraria La Molina, Lima, Perú.*

^c^ Present affiliation: *Instituto de Investigación para el Desarrollo Sustentable de Ceja de Selva, Universidad Nacional Toribio Rodríguez de Mendoza de Amazonas, Chachapoyas, Peru.*

\*Corresponding author. Email: [flozanoisla@gmail.com](mailto:flozanoisla@gmail.com) 

ORCiD IDs:

Flavio Lozano-Isla: 0000-0002-0714-669X

Elizabeth Heros-Aguilar: 0000-0002-0179-3124

Andres Casas-Diaz: 0000-0001-7461-3924



**Declarations**

**Funding**

This work was supported by the National Agrarian University La Molina through the Center for Educational Innovation and the Research Unit of the Faculty of Agronomy.

**Conflicts of interest**

No potential conflict of interest was reported by the authors

**Data and code availability** 

The data analysis was performed using Quarto, an open-source platform designed for reproducibility for scientific and technical publishing. Access to data and the analysis can be found in the supplementary information.

**Author contributions**

Flavio Lozano-Isla: Conceptualization, Data curation, Formal analysis, Investigation, Methodology, Writing – original draft. Elizabeth Heros-Aguilar: Project administration, Validation, Writing – review & editing. Andres Casas-Diaz: Supervision, Writing – review & editing.

**Acknowledgments**

To E. Rios and V. Landa for capacitation and their motivation to improve the course that resulted in the present manuscript. To R. Ortiz for suggestions to improve the manuscript. To the students who participated in the project.

**Ethics statement**

The project was endorsed and approved by the university. The participants were informed of the study's purpose, and their participation was voluntary and anonymous.



# Abstract

Plant genetics lectures can be challenging for students to understand due to the abstract nature of the concepts discussed. This generates a lack of interest in students due to the isolation between theoretical and practical concepts which limits critical thinking in students. Virtualization due to the COVID-19 pandemic aggravated this situation with the lack of practical classes due to the closure of laboratories and experimental fields in universities. This work introduces the establishment of a Journal Club (JC) with the collaborative-metacognitive use of the scientific literature teaching approach as a strategy to reinforce theoretical-practical knowledge through the reading of scientific articles in an e-learning environment. The methodology was applied in two consecutive academic semesters in years 2021 and 2022 in the plant genetics lectures. The students read scientific articles and performed an essay in groups. The results show that more than 80% of the participants agree with the JC implementation and they consider it relevant to their education. The application of the JC allowed the students to integrate knowledge covered in the theoretical lectures. Additionally, students presented improvements in skills within the framework of the seven Cs for critical thinking, teamwork, use of research tools, and essay writing scores.

**Keywords:** CMSLTA, crop sciences, research tools, sci-hub, seven Cs, Zotero

# 

```Unknown element type at this position: UNSUPPORTED```# Introduction

The World Health Organization on 11^th^ March 2020 declared a pandemic caused by the SARS-CoV-2 outbreak. This brought a new challenge for students and lecturers to implement remote distance learning worldwide [[1, 2]](https://www.zotero.org/google-docs/?PHXGqF). Video conferencing tools like Zoom, Google Meet, and Microsoft Teams have become the predominant means of both education and social interaction.

The journal club (JC) is a longstanding and widely used method in undergraduate and graduate teaching, with a history that extends over approximately 200 years [[3]](https://www.zotero.org/google-docs/?uQG5Nf). Dr. James Paget coined the term "journal club" in 1835. Initially, It was so named because doctors at St. Bartholomew's Hospital in London would gather in a room to read medical journals. However, in 1875, Sir William Osler transformed these gatherings into regular meetings where doctors and students convened to critique and deliberate over published materials. As a result, journal clubs have established a strong and long tradition in the medical sciences [[4]](https://www.zotero.org/google-docs/?RKc2ri).

The initial purpose of a Journal Club (JC) was to assist physicians in keeping up to date with the latest research and applying research findings in clinical practice. It fosters collaborative learning and encourages the cultivation of continuous studying [[5]](https://www.zotero.org/google-docs/?Qp7RYE). However many aims can be achieved by participants during JC sessions, such as spreading scientific information and knowledge transfer, keeping up to date with the literature, and developing critical thinking or analytical skills. The JC also acts as a motivating tool [[6]](https://www.zotero.org/google-docs/?wi6LC5) and makes studying more manageable. While journal clubs have been integrated into the medical education system [[7]](https://www.zotero.org/google-docs/?Pd0S9a), there is a scarcity of research examining the efficacy of journal clubs in imparting evidence-based practices to professionals in the field of plant science.

The present work was part of a pedagogical training course entitled "Designing my course" for professors starting their academic careers at the university. Each professor was encouraged to implement an improvement methodology in one of the lectures of his or her specialty. We describe and analyze the implementation of an e-learning JC during two academic semesters for plant genetics lectures as a collaborative-metacognitive use of science literature teaching approach (CMSLTA).

The primary hypothesis posited that the integration of JC could enhance the ability to connect lecture topics in an environment where practical knowledge was limited due to COVID-19 restrictions. 

# Conceptual framing: e-Learning, Journal Club, CMSLTA, Seven Cs and pedagogy 

## e-Learning: online or distance learning

e-learning is a term that refers to online or distance learning, which uses digital technologies to deliver education and training over the Internet  [[8, 9]](https://www.zotero.org/google-docs/?aK7hST). Learning materials are delivered through an online learning platform and may include videos, readings, quizzes, discussion forums, and other interactive activities [[10]](https://www.zotero.org/google-docs/?SAWuOG). Students can access learning materials from anywhere and at any time, giving them greater flexibility in their learning [[11]](https://www.zotero.org/google-docs/?hfhIKN).

During the COVID-19 pandemic, many universities around the world adopted e-learning to continue online teaching and learning [[1]](https://www.zotero.org/google-docs/?tcBAPq). The pandemic forced many educational institutions to temporarily close their campuses and look for alternatives to continue offering education to students [[12]](https://www.zotero.org/google-docs/?bxDL1p). e-learning became a popular option, allowing students to continue their education from home and remain safe during the pandemic. Many universities use online tools and platforms to offer live, recorded lectures, assignments, and assessments to students.

## Journal Club

A journal club is a group meeting where recent scientific articles are discussed. These meetings are common in academic and medical settings, but can also be held in other contexts, such as in a company or study group [[6, 13, 14]](https://www.zotero.org/google-docs/?vuAU0q). For over a century, physicians have widely utilized journal clubs as a valuable tool for enhancing their critical assessment skills [[4, 7, 15]](https://www.zotero.org/google-docs/?6nHKEE).

The main objective of a journal club is to promote critical discussion and exchange of ideas about recent research in a given field. Participants read and analyze selected articles before the meeting, and then discuss their findings, methods, and conclusions. This helps keep participants updated with the latest research and allows them to learn from others [[5]](https://www.zotero.org/google-docs/?2g8YEC). A journal club can also be an opportunity to improve critical and communication skills, as participants must explain and justify their views in a respectful and constructive environment.

In a university environment, a journal club can be an excellent way to encourage critical discussion and the exchange of ideas between students and professors. Students can have the opportunity to learn from professors and peers about the latest research in their field, and professors can take the opportunity to guide students in critically analyzing the literature [[14]](https://www.zotero.org/google-docs/?3mNGIe).

## Collaborative-metacognitive use of science literature teaching approach (CMSLTA)

The Collaborative-metacognitive use of science literature teaching approach (CMSLTA) is a pedagogical strategy that focuses on the use of collaborative and metacognitive scientific literature to enhance comprehension and critical thinking in science students [[16]](https://www.zotero.org/google-docs/?GUU9dV). The goal of the CMSLTA approach is to help students develop skills in reading, comprehending, analyzing, and evaluating scientific texts, as well as working in teams to discuss and solve complex problems in science [[17, 18]](https://www.zotero.org/google-docs/?Xigcp8). The CMSLTA strategy is based on the idea that active and collaborative learning, as well as metacognitive reflection on the learning process itself, can enhance understanding of science and promote advanced cognitive skills.

The journal club could be considered CMSLTA. It refers to a teaching approach that engages students in the discussion and critical analysis of scientific literature, with a focus on the development of metacognitive skills, such as reflection and self-regulation.

In the context of the present implementation of JC, students work together to read and analyze scientific articles and discuss their findings, methods, and conclusions. This allows them to develop metacognitive skills by reflecting on their learning process and considering the perspective of others. In addition, working collaboratively in a journal club allows students to learn from their peers and teachers, and improve their communication and presentation skills. It also allows them to learn to work in teams and to develop leadership and problem-solving skills. 

## Seven Cs

The concept of the seven Cs refers to a framework of twenty-first-century skills. It is composed of seven key elements: communication, collaboration, creativity, critical thinking, cross-cultural understanding, computerized/information and communication technologies, and career/lifelong learning [[16]](https://www.zotero.org/google-docs/?zdVyo0). These elements are important for any type of communication, whether written or oral, and are especially useful in professional and academic environments. By following the principles of the seven Cs, the quality of communication can be improved and the comprehension and effectiveness of the messages transmitted can be increased. 

The implementation of a journal club could reinforce the following concepts:

1. Communication: The JC allows students to develop their communication skills by presenting their findings and discussing their ideas with their peers and professors.
1. Collaboration: By working together to analyze and discuss scientific literature, students can develop collaborative skills and learn to work as a team.
1. Critical thinking: By analyzing and discussing scientific literature, students can develop their ability to think outside the box and find creative solutions to scientific problems.
1. Criticism: By evaluating and discussing scientific literature, students can develop their critical thinking skills and evaluation of evidence.
1. Cross-cultural understanding: By learning about research in a global context, students can develop a deeper and more respectful understanding of different cultures and perspectives.
1. Computerized/information and communication technologies: By using technology to explore, read, and discuss scientific literature, students can develop their digital skills.
1. Career/lifelong learning: JC is an active learning methodology that promotes keeping up-to-date with the literature and promotes self-learning allowing long-term learning.

## Pedagogical Skills in Science Education

University professors usually have specialized academic training in their field of study, however, they may lack the pedagogical skills to teach science. Many university professors have obtained additional training in pedagogy or have experience teaching science [[10]](https://www.zotero.org/google-docs/?OsX5Ky). Some university professors may not have formal pedagogical training and may have difficulty applying effective teaching techniques. The universities can provide training and support to help professors develop pedagogical skills [[19]](https://www.zotero.org/google-docs/?Su6VPG). The pandemic highlighted the continuous necessity for educational research focused on pedagogy [[20]](https://www.zotero.org/google-docs/?UjIAfT). Additionally, it emphasized the importance of investigating how instructors can optimally transition their teaching methods from face-to-face to remote modalities [[21]](https://www.zotero.org/google-docs/?2soY6V).

The journal club could be classified as an active and participatory pedagogical tool. In this type of teaching, students are responsible for their learning and actively participate in the discussion and analysis of scientific literature [[22]](https://www.zotero.org/google-docs/?ZeYNbJ). 

```Unknown element type at this position: UNSUPPORTED```# Method

## Scope and Delimitations

The journal club (JC) was implemented in the plant genetics lecture. A total of 90 third-year agronomy students participated. The implementation took place during two academic semesters in the years 2021 and 2022. Each academic semester has a period of 16 weeks. The project was endorsed and approved by the university. The students were informed of the project and the surveys were conducted voluntarily.

## Teaching Approach

At the beginning of the course, all students received training in the use of tools and web resources. Each journal club (i.e., article) was divided into three weeks with a duration of 60 minutes per session. In the first week, students began by reading the article, in the second week, they focused on writing their essays, and in the third week, the article was discussed collectively ([Figure  @fig:kix.496kixf5gqtx]:). Despite the oral language being Spanish, all the articles were read in English ([Table  @tbl:id.85ly0lr9xnr1]:). All sessions were conducted virtually through the Zoom platform. The methodology is explained in more detail below:



```Unknown element type at this position: UNSUPPORTED```




| **JC**                                                                                                                                                                                            | **Semester**                                                                                                                                                                                      | **Title**                                                                                                                                                                                         | **Year**                                                                                                                                                                                          | **Journal**                                                                                                                                                                                       | **Type**                                                                                                                                                                                           |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1                                                                                                                                                                                                 | 2021                                                                                                                                                                                              | [Breeding crops to feed 10 billion](https://www.nature.com/articles/s41587-019-0152-9)                                                                                                            | 2019                                                                                                                                                                                              | nature biotechnology                                                                                                                                                                              | review article                                                                                                                                                                                     |
| 2                                                                                                                                                                                                 | 2021                                                                                                                                                                                              | [Imaged-based phenotyping accelerated QTL mapping and qtl × environment interaction analysis of testa colour in peanut (Arachis hypogaea)](https://onlinelibrary.wiley.com/doi/10.1111/pbr.12905) | 2021                                                                                                                                                                                              | plant breeding                                                                                                                                                                                    | research article                                                                                                                                                                                   |
| 3                                                                                                                                                                                                 | 2021                                                                                                                                                                                              | [Genetic patterns offer clues to evolution of homosexuality](https://www.nature.com/articles/d41586-021-02312-0)                                                                                  | 2021                                                                                                                                                                                              | nature                                                                                                                                                                                            | news                                                                                                                                                                                               |
| 4                                                                                                                                                                                                 | 2021                                                                                                                                                                                              | [Heritability in Morphological Robot Evolution](https://doi.org/10.48550/arXiv.2110.11187)                                                                                                        | 2021                                                                                                                                                                                              | arxiv                                                                                                                                                                                             | research article                                                                                                                                                                                   |
| 1                                                                                                                                                                                                 | 2022                                                                                                                                                                                              | [Genome-edited crops for improved food security of smallholder farmers](https://www.nature.com/articles/s41588-022-01046-7)                                                                       | 2022                                                                                                                                                                                              | nature genetics                                                                                                                                                                                   | review article                                                                                                                                                                                     |
| 2                                                                                                                                                                                                 | 2022                                                                                                                                                                                              | [Crucial factors for the feasibility of commercial hybrid breeding in food crops](https://www.nature.com/articles/s41477-022-01142-w#Tab1)                                                        | 2022                                                                                                                                                                                              | nature plants                                                                                                                                                                                     | review article                                                                                                                                                                                     |
| 3                                                                                                                                                                                                 | 2022                                                                                                                                                                                              | [Semiautomated Feature Extraction from RGB Images for Sorghum Panicle Architecture GWAS](https://academic.oup.com/plphys/article/179/1/24/6116437)                                                | 2019                                                                                                                                                                                              | plant physiology                                                                                                                                                                                  | research article                                                                                                                                                                                   |
| 4                                                                                                                                                                                                 | 2022                                                                                                                                                                                              | [A chromosome predisposed for sex](https://www.nature.com/articles/d41586-022-01129-9)                                                                                                            | 2022                                                                                                                                                                                              | nature                                                                                                                                                                                            | news                                                                                                                                                                                               |




: Reading materials for the journal club implemented during the academic semesters of 2021 and 2022 in the plant genetics lectures amidst the challenges of the COVID-19 pandemic {#tbl:id.85ly0lr9xnr1}



```Unknown element type at this position: UNSUPPORTED```**Training - Research tools:** Students learn diverse tools that will enable the appropriate use of software and applications for reading articles and writing essays. Among these tools was Zotero in the desktop version as the web connector, Google Docs, Hypothesis, and web translators (i.e., Google Translate, DeepL, and DocTranslator), and Articul8 (Google Docs extension). The training stage was in the first week of each semester and took 120 minutes.

**Week 1 - Reading articles:** Students were assigned into random groups of three to four. The groups and the randomization were made automatically in the Moodle system. At the beginning of the session, the article was introduced and the students had 30 minutes to read it and extract all the essential information. At the end of the reading time, the main points in the article are discussed (i.e. topic, research question, hypothesis, and main results).

**Week 2 - Essay writing:** In the first 40 minutes the students in groups began to organize the writing of their essays. In the remaining 20 minutes, guidance on how to improve the essay writing or provide feedback from the previous JC was conducted. 

**Week 3 - Reading discussion:** In the first 30 minutes, students were randomly grouped with members of other groups to discuss their ideas and points of view based on the article read. At the end of that period, all students were returned to the main room for the general discussion guided by the professor. In case there were no initial opinions, the professor asked questions and probed their reading to encourage further discussion by presenting different ideas and opinions. In some sessions, slides were used to present case studies or experiences about the article topic to motivate the discussion. At the end of the session, the students have to submit their essays as the final product of JC.



![Journal club teaching approach implemented in plant genetics lectures during two academic semesters in years 2021 and 2022. During the training, the students learned different tools to read, write, and discuss scientific documents. In week 1, the article was shared and the students began reading it. The students in groups started writing their essays in week 2, while in week 3, they discussed in random groups the assigned paper. Four journal clubs were conducted for each academic semester.](img_0.png){#fig:kix.496kixf5gqtx}

## Instrument

**Survey design:** A survey was designed to determine the level of satisfaction with the JC implementation. In addition, objective questions were included to evaluate the tools that participants learned and used during the course ([Table  @tbl:kix.j6aj6xi5zazn]:). The survey was voluntary and anonymous to allow students to express their opinions without any restrictions.






| **Number**                                                   | **Question**                                                  |
|--------------------------------------------------------------|---------------------------------------------------------------|
| 1                                                            | Were the articles difficult to understand?                    |
| 2                                                            | Was the time for each journal club adequate?                  |
| 3                                                            | Should we read fewer articles?                                |
| 4                                                            | Should we read more articles?                                 |
| 5                                                            | Was the number of articles appropriate?                       |
| 7                                                            | Did you like the articles?                                    |
| 8                                                            | Do you consider the journal club relevant to your education?  |
| 9                                                            | Do you agree with its implementation?                         |




: Questions of the survey to evaluate the level of satisfaction of the journal club in the plant genetics lectures during the period 2021 and 2022. {#tbl:kix.j6aj6xi5zazn}

**Objective rubric:** Writing an essay was the final product of each journal club series (i.e., every three weeks). Grading was based on the use of an objective rubric. The grading system was from 0 to 20, where 20 is the highest grade. The names of the participants were removed from the grading book to maintain the privacy of the students.



## Data Collection and Analysis

Data analysis was performed in the statistical software R version 4.2.2 ([R Core Team, 2020](https://www.zotero.org/google-docs/?U07ghK)). The scores were analyzed in a linear model taking into account the interaction of the factors: the journal club sessions, the section, and the semester of methodology implementation. The obtained results underwent analysis of variance to assess the interaction between the factors. The estimated marginal means and the pairwise comparisons test were performed with *emmeans* [[24]](https://www.zotero.org/google-docs/?lIGMen) and *multcomp* [[25]](https://www.zotero.org/google-docs/?pVBDKG) R package respectively. The graphs were made with the *inti* package. Qualitative data analysis and graphs were analyzed by the frequency of occurrence of terms with the *wordcloud* package [[26]](https://www.zotero.org/google-docs/?2YZZUI). 

The replicable analysis was carried out utilizing Quarto, an open-source system for scientific and technical publishing [[27]](https://www.zotero.org/google-docs/?dAkyH6)

# 

# Results

## Student perception

An objective survey was designed to evaluate the students' perception of the journal club under synchronous e-learning due COVID-19 pandemic. The survey was applied at the end of the semester at plant genetic lectures during two academic semesters in the years 2021 and 2022. 

About 84.4% of the students agreed with the JC implementation and 83.3% considered it relevant to their education. Regarding the article read, 74.4% liked the articles chosen, whereas 84.4% indicated that the number of articles was adequate for the duration of the course. Additionally, 60% considered not reducing the number of articles, and 45% suggested increasing the number of articles to read. According to 87.8% of students, the timelapse for each JC was adequate. At least 14% of the students rated the chosen articles as difficult to understand, whereas 72.2% of students found their understanding medium to difficult ([Figure  @fig:id.pmcc7d4jkx1a]:).



![Student perception on the application of the journal club teaching approach during two academic semesters in years 2021 and 2022 in the plant genetics lectures. The dashed line represents 75% of the participants and NA represents the questions not answered by the students. Results were based on a survey conducted on 90 students.](img_1.png){#fig:id.pmcc7d4jkx1a}

## Research tools and training 

The frequency with which each tool was used by the students was evaluated to determine the relevance of the training in the use of research tools during JC implementation

The frequency of the tools was divided into five groups represented by the colors: forest-green, blue, orange, purple, and gray ([Figure  @fig:id.6pfwogtac6re]:). The first group included Google Docs, Google Scholar, and Zotero with 11.9%, 10.7%, and 10.3%, respectively; while Sci-Hub and iLovePDF were in the second group with 9.3% and 9.1% respectively. The third group only included onlinedoctranslator with 5.6%. DeepL, Scimago Journal & Country Rank, and Foxit Reader were in the fourth group with 4.2%, 3.8%, and 3%, respectively. Tools such as Hypothesis, Articul8, and Grammarly represented less than 3% each.

![Research tools learned and used by students during the implementation of the journal club in the plant genetics lectures during the period  2021 and 2022.  Results based on the frequency with which each tool was mentioned in 90 students surveyed.](img_2.png){#fig:id.6pfwogtac6re}

## Progress in essay grades

The present implementation includes essay writing to enhance conceptual understanding, foster critical thinking, and develop communication skills (Dowd et al. 2018). Essay by groups was the final product of each journal club. Essay grades after each journal club were compared among the five sections during two academic semesters in the plant genetics lecture.

Sections A and D presented an increase in the grades in time in both semesters. In the 2021-2 semester group A started with a score of 17.5 and at the end got a score of 18.4, whereas group D had 17 and 17.2, respectively, for the same evaluations. In the 2022-1 semester group A started with 14.8 and ended with a score of 17.9, whereas group D had 16.5 and 18.6 gradings, respectively, for the same evaluations. For both sections, A and D showed a continued improvement in their grading over time during the two academic semesters ([Figure  @fig:id.y18qqmtszisb]:). Section D reduced their grading in 2021-1 for JC two and four and JC three in 2022-1 ([Figure  @fig:id.y18qqmtszisb]:). This reduction was associated with the type of articles (i.e., research articles, [Table  @tbl:id.85ly0lr9xnr1]:).

Section B in the 2022-1 semester did not show an improvement in the grading during the period of the JC. The initial grading for this group was 15.5 and ended with a grading of 15.0 ([Figure  @fig:id.y18qqmtszisb]:).

![Essays grading during the implementation of journal club during two academic semesters in years 2021 and 2022 for synchronous e-learning at plant genetics lectures in five different sections. The grading system was from 0 to 20, where 20 is the highest grade. Results were based on the grading book from the five sections with a total of 90 students.](img_3.png){#fig:id.y18qqmtszisb}

# 

```Unknown element type at this position: UNSUPPORTED```# Discussion 

With the advent of the COVID-19 pandemic in 2020, there was a huge change in the development of lectures in universities worldwide [[1, 21, 28]](https://www.zotero.org/google-docs/?JNDh8q). Synchronous and asynchronous e-learning became the main environment in which students interacted. Active learning classroom strategies need to be generated to engage the interest and motivation of students [[29]](https://www.zotero.org/google-docs/?iIpTun). In this context, JC could be considered a project-based pedagogical tool, as students are tasked with reading and analyzing scientific articles and then presenting and discussing their findings (i.e. essay). We analyzed the implementation of a synchronous e-learning journal club at plant genetics lectures. The results show that there is a positive perception of students towards the implementation of a journal club based on the application of a collaborative-metacognitive use of science literature teaching approach (CMSLTA). 

For a long time, JC was used for teaching and knowledge sharing in medicine [[13, 28]](https://www.zotero.org/google-docs/?r9mwoa), and in post-graduate education [[30]](https://www.zotero.org/google-docs/?GfRcyR). The use of the JC approach has been proven to be educationally valuable. It assists in the development of critical critique skills, raises awareness of research, empowers professionals, fosters a positive research culture, and promotes evidence-based practice [[31]](https://www.zotero.org/google-docs/?3Vi89N). The JC implementation received excellent feedback from participants. Our results reveal that 83% of the participants who participated in the implementation of the JC in the plant genetics lecture found it productive, and relevant to their formal education and they agreed with its implementation.

Meetings lasted ca.1 hour per week. Student interaction was improved since the activities were in groups and open discussions with all the participants. Additionally, the students showed an improvement in their academic reading ability because the JC implies active learning [[32]](https://www.zotero.org/google-docs/?6z4JE3). Nevertheless, there was a reduction in grades when the students were exposed to reading and discussing research articles. However, there was an increase in the grading in four out of the five groups in the two evaluated academic semesters. Similar results were found by other authors during the JC sessions where the participants showed increased knowledge and critical thinking [[7, 14, 30]](https://www.zotero.org/google-docs/?fKUFdz). 

In plant sciences courses, field practices are an important component in the education of the students [[33]](https://www.zotero.org/google-docs/?oTkCCh). The shutdown of university campuses as a result of the COVID-19 pandemic and the rapid shift to online courses resulted in students becoming isolated from their respective universities, leading to a detrimental impact on their educational experience [[34, 35]](https://www.zotero.org/google-docs/?skHPAa). The JC is presented as a relevant alternative to an e-learning approach to promoting the discussion and participation of students to strengthen the knowledge acquired in theoretical lectures. In addition, the curricular structure of the lectures (i.e. syllabus) describes the themes presented in an isolated manner, which makes it difficult to understand the knowledge as a whole. By utilizing the CMSLTA approach within the JC, students are empowered to explore and analyze the latest scholarly literature while actively discussing its relevance and practical applications. Moreover, the incorporation of this approach not only fosters problem-solving skills but also promotes collaboration. It empowers students by providing them with tools to apply their acquired knowledge to real-world situations.

The implementation of a JC at plant genetics helps strengthen skills such as critical thinking, teamwork, independent learning, tolerance to different opinions, and digital skills included in the seven Cs framework. An advantage of implementing a journal club with essay writing is the reduction of cheating and plagiarism [[36]](https://www.zotero.org/google-docs/?DKO3gL).  The use of articles allows for the diversification of readings in each semester. In most cases, the students benefit from the state of the art in the studied area and associate the theoretical knowledge that they are learning. However, our findings indicate that numerous students turn to platforms such as Sci-Hub due to limited access to up-to-date study materials, as the universities are not subscribed to relevant journals [[37]](https://www.zotero.org/google-docs/?jIbyoD). It is essential to recognize that employing such resources involves infringing intellectual property rights and copyright laws [[38]](https://www.zotero.org/google-docs/?FgOTXL). Consequently, it becomes imperative to pursue legitimate and ethical alternatives that enable university students to access academic information while upholding the principles of copyright laws [[39]](https://www.zotero.org/google-docs/?W4XOUc).

The limitation of the present work was the design of the instrument for qualitative data collection. The methodology used for the instrument was based on survey research methods. The authors recognize that the survey would have yielded more detailed and comprehensive data. The choice was made to collect preliminary data and timely analysis of the application of JC during the COVID-19 pandemic as an active learning strategy. Despite the limitations, the authors believe that the present study provides valuable information for the application of the JC approach.

The implementation of JC even after the post-COVID pandemic could be productive as some universities continue with a hybrid model for online teaching-learning because they provide a flexible and feasible platform for evidence-based e-learning [[28]](https://www.zotero.org/google-docs/?3zvTGC). Educators' perspective support the idea that we should teach science as a means of acquiring knowledge, emphasizing the procedures of scientific inquiry rather than the mere memorization of facts [[40]](https://www.zotero.org/google-docs/?6t00Gm). The JC is an effective active pedagogical tool to promote project-based learning, which allows students to learn autonomously and apply their knowledge to real situations. The implementation of a JC promotes the development of skills contained in the Seven Cs and the critical analysis of scientific literature, with a focus on the development of metacognitive and collaborative skills. 

# Conclusion

Implementing a journal club in plant science course has presented an alternative that promotes students' engagement with their learning and created a venue for academic discussions under the lack of field practice. The students perceive the JC as relevant to their formal education and they agree with its implementation. Additionally, the JC allows students to complement their theoretical knowledge and develop soft skills that are essential for success in the modern world and their lifelong learning. The dynamic learning experience of JC remains applicable and relevant beyond the confines of the COVID-19 pandemic, whether in an e-learning setting or through traditional face-to-face lectures.

# 

# References

[1. 	Daniel, Sir John. 2020. Education and the COVID-19 pandemic. *Prospects* 49: 91–96. https://doi.org/10.1007/s11125-020-09464-3.](https://www.zotero.org/google-docs/?JVULmA)

[2. 	Harris, Breanna N., Pumtiwitt C. McCarthy, April M. Wright, Heidi Schutz, Kate S. Boersma, Stephanie L. Shepherd, Lathiena A. Manning, Jessica L. Malisch, and Roni M. Ellington. 2020. From panic to pedagogy: Using online active learning to promote inclusive instruction in ecology and evolutionary biology courses and beyond. *Ecology and Evolution* 10: 12581–12612. https://doi.org/10.1002/ece3.6915.](https://www.zotero.org/google-docs/?JVULmA)

[3. 	Topf, Joel M., Matthew A. Sparks, Paul J. Phelan, Nikhil Shah, Edgar V. Lerma, Matthew P. M. Graham-Brown, Hector Madariaga, et al. 2017. The Evolution of the Journal Club: From Osler to Twitter. *American Journal of Kidney Diseases* 69. Elsevier: 827–836. https://doi.org/10.1053/j.ajkd.2016.12.012.](https://www.zotero.org/google-docs/?JVULmA)

[4. 	Linzer, M. 1987. The journal club and medical education: over one hundred years of unrecorded history. *Postgraduate Medical Journal* 63. The Fellowship of Postgraduate Medicine: 475–478. https://doi.org/10.1136/pgmj.63.740.475.](https://www.zotero.org/google-docs/?JVULmA)

[5. 	Wenke, Rachel, Paulina Stehlik, John Gerrard, Sharon Mickan, and David Henry. 2023. Using a journal club to navigate a maze of COVID-19 papers in a front-line hospital service. *BMJ Evidence-Based Medicine*. Royal Society of Medicine. https://doi.org/10.1136/bmjebm-2022-112130.](https://www.zotero.org/google-docs/?JVULmA)

[6. 	Sanwatsarkar, Sadhana, Sanjeev Palta, Satyen Parida, Chaitanya Kamat, and Bala Subramanya H. 2022. How to do a journal club, a seminar and a webinar? *Indian Journal of Anaesthesia* 66: 27–33. https://doi.org/10.4103/ija.ija\_1108\_21.](https://www.zotero.org/google-docs/?JVULmA)

[7. 	Ilic, Dragan, Annelies de Voogt, and John Oldroyd. 2020. The use of journal clubs to teach evidence-based medicine to health professionals: A systematic review and meta-analysis. *Journal of Evidence-Based Medicine* 13: 42–56. https://doi.org/10.1111/jebm.12370.](https://www.zotero.org/google-docs/?JVULmA)

[8. 	Clark, Ruth C., and Richard E. Mayer. 2016. *E-learning and the science of instruction: Proven guidelines for consumers and designers of multimedia learning*. john Wiley & sons.](https://www.zotero.org/google-docs/?JVULmA)

[9. 	Mahdizadeh, Hossein, Harm Biemans, and Martin Mulder. 2008. Determining factors of the use of e-learning environments by university teachers. *Computers & Education* 51: 142–154. https://doi.org/10.1016/j.compedu.2007.04.004.](https://www.zotero.org/google-docs/?JVULmA)

[10. 	Ganzert, Markus, Stefan Huber, Muhammed Kaya, Serkan Sepin, and Philipp Melzer. 2017. Adoption, Usage, and Pedagogy of E-Learning Tools in University  Teaching. *UK Academy for Information Systems Conference Proceedings 2017*.](https://www.zotero.org/google-docs/?JVULmA)

[11. 	Mayer, Richard E. 2003. Elements of a Science of E-Learning. *Journal of Educational Computing Research* 29. SAGE Publications Inc: 297–313. https://doi.org/10.2190/YJLG-09F9-XKAX-753D.](https://www.zotero.org/google-docs/?JVULmA)

[12. 	Mahdi, Zahra Al. 2023. Enhancement of Technology in Pedagogy and Practice in Higher Education during Covid-19. *SHS Web of Conferences* 156. EDP Sciences: 05001. https://doi.org/10.1051/shsconf/202315605001.](https://www.zotero.org/google-docs/?JVULmA)

[13. 	Aweid, Bashaar, Zakir Haider, Maya Wehbe, and Alistair Hunter. 2022. Educational benefits of the online journal club: A systematic review. *Medical Teacher* 44. Taylor & Francis: 57–62. https://doi.org/10.1080/0142159X.2021.1963424.](https://www.zotero.org/google-docs/?JVULmA)

[14. 	Golden, Aaron. 2023. Teaching graduate research skills in genomics via an integrated ‘flipped’ journal club program. *Biochemistry and Molecular Biology Education* 51: 57–64. https://doi.org/10.1002/bmb.21694.](https://www.zotero.org/google-docs/?JVULmA)

[15. 	Ianno, Damian James, Kelly Mirowska-Allen, Stephen Anthony Kunz, and Richard O’Brien. 2020. Journal clubs in Australian medical schools: prevalence, application, and educators’ opinions. *Journal of Educational Evaluation for Health Professions* 17. Korea Health Personnel Licensing Examination Institute. https://doi.org/10.3352/jeehp.2020.17.9.](https://www.zotero.org/google-docs/?JVULmA)

[16. 	Daloos, Ma. Lara Angela Santos, and Edwehna Elinore S. Paderna. 2023. Enhancing Students’ Concept Understanding Through Collaborative-Metacognitive Use of Science Literature. *Research in Science Education* 53: 81–97. https://doi.org/10.1007/s11165-022-10049-7.](https://www.zotero.org/google-docs/?JVULmA)

[17. 	Hogan, Michael J., Christopher P. Dwyer, Owen M. Harney, Chris Noone, and Ronan J. Conway. 2015. Metacognitive Skill Development and Applied Systems Science: A Framework of Metacognitive Skills, Self-regulatory Functions and Real-World Applications. In *Metacognition: Fundaments, Applications, and Trends: A Profile of the Current State-Of-The-Art*, ed. Alejandro Peña-Ayala, 75–106. Intelligent Systems Reference Library. Cham: Springer International Publishing. https://doi.org/10.1007/978-3-319-11062-2\_4.](https://www.zotero.org/google-docs/?JVULmA)

[18. 	Sandi‐Urena, Santiago, Melanie M. Cooper, and Ron H. Stevens. 2011. Enhancement of Metacognition Use and Awareness by Means of a Collaborative Intervention. *International Journal of Science Education* 33. Routledge: 323–340. https://doi.org/10.1080/09500690903452922.](https://www.zotero.org/google-docs/?JVULmA)

[19. 	Zohar, Anat, and Noa Schwartzer. 2011. Assessing Teachers’ Pedagogical Knowledge in the Context of Teaching Higher‐order Thinking. *International Journal of Science Education* 27. Routledge: 1595–1620. https://doi.org/10.1080/09500690500186592.](https://www.zotero.org/google-docs/?JVULmA)

[20. 	Singer, Susan R., Natalie R. Nielsen, and Heidi A. Schweingruber. 2013. Biology Education Research: Lessons and Future Directions. *CBE—Life Sciences Education* 12. American Society for Cell Biology (lse): 129–132. https://doi.org/10.1187/cbe.13-03-0058.](https://www.zotero.org/google-docs/?JVULmA)

[21. 	Barton, Daniel C. 2020. Impacts of the COVID-19 pandemic on field instruction and remote teaching alternatives: Results from a survey of instructors. *Ecology and Evolution* 10: 12499–12507. https://doi.org/10.1002/ece3.6628.](https://www.zotero.org/google-docs/?JVULmA)

[22. 	Shah, Veenita, Sahana Murthy, Jayakrishnan Warriem, Sameer Sahasrabudhe, Gargi Banerjee, and Sridhar Iyer. 2022. Learner-centric MOOC model: a pedagogical design model towards active learner participation and higher completion rates. *Educational technology research and development* 70: 263–288. https://doi.org/10.1007/s11423-022-10081-4.](https://www.zotero.org/google-docs/?JVULmA)

[23. 	R Core Team. 2020. *R: A language and environment for statistical computing*. Manual. Vienna, Austria.](https://www.zotero.org/google-docs/?JVULmA)

[24. 	Lenth, Russell V., Paul Buerkner, Iago Giné-Vázquez, Maxime Herve, Maarten Jung, Jonathon Love, Fernando Miguez, Hannes Riebl, and Henrik Singmann. 2023. emmeans: Estimated Marginal Means, aka Least-Squares Means. https://cran.r-project.org/package=emmeans.](https://www.zotero.org/google-docs/?JVULmA)

[25. 	Hothorn, Torsten, Frank Bretz, Peter Westfall, Richard M. Heiberger, Andre Schuetzenmeister, and Susan Scheibe. 2023. multcomp: Simultaneous Inference in General Parametric Models. https://cran.r-project.org/package=multcomp.](https://www.zotero.org/google-docs/?JVULmA)

[26. 	Fellows, Ian. 2018. wordcloud: Word Clouds.](https://www.zotero.org/google-docs/?JVULmA)

[27. 	Allaire, J.J., Charles Teague, Carlos Scheidegger, Yihui Xie, and Christophe Dervieux. 2023. Quarto: open-source scientific and technical publishing system built on Pandoc. https://quarto.org/.](https://www.zotero.org/google-docs/?JVULmA)

[28. 	Ozkara, Burak Berksu, Mert Karabacak, and Duygu Demet Alpaydin. 2022. Student-Run Online Journal Club Initiative During a Time of Crisis: Survey Study. *JMIR Medical Education* 8: e33612. https://doi.org/10.2196/33612.](https://www.zotero.org/google-docs/?JVULmA)

[29. 	Garcia-Vedrenne, Ana E., Chloé Orland, Kimberly M. Ballare, Beth Shapiro, and Robert K. Wayne. 2020. Ten strategies for a successful transition to remote learning: Lessons learned with a flipped course. *Ecology and Evolution* 10: 12620–12634. https://doi.org/10.1002/ece3.6760.](https://www.zotero.org/google-docs/?JVULmA)

[30. 	Taverna, Mara, Julian Nicolaus Bucher, Maximilian Weniger, Roswitha Gropp, Serene M. L. Lee, Barbara Mayer, Jens Werner, and Alexandr V. Bazhin. 2022. Perception of journal club seminars by medical doctoral students: results from five years of evaluation. *GMS Journal for Medical Education* 39. German Medical Science GMS Publishing House. https://doi.org/10.3205/zma001525.](https://www.zotero.org/google-docs/?JVULmA)

[31. 	Xiong, Li, Anne-Katrin Giese, Marco Pasi, Andreas Charidimou, Susanne van Veluw, and Anand Viswanathan. 2018. How to Organize a Journal Club for Fellows and Residents. *Stroke* 49. American Heart Association: 283–285. https://doi.org/10.1161/STROKEAHA.118.021728.](https://www.zotero.org/google-docs/?JVULmA)

[32. 	Ragland, Elizabeth C, Scott Radcliffe, and Elizabeth L Karcher. 2023. A review of the application of active learning pedagogies in undergraduate animal science curricula. *Journal of Animal Science* 101. https://doi.org/10.1093/jas/skac352.](https://www.zotero.org/google-docs/?JVULmA)

[33. 	Fleischner, Thomas L., Robert E. Espinoza, Gretchen A. Gerrish, Harry W. Greene, Robin Wall Kimmerer, Eileen A. Lacey, Steven Pace, et al. 2017. Teaching Biology in the Field: Importance, Challenges, and Solutions. *BioScience* 67: 558–567. https://doi.org/10.1093/biosci/bix036.](https://www.zotero.org/google-docs/?JVULmA)

[34. 	McKim, Aaron J., Tyson J. Sorensen, and Michelle Burrows. 2021. The COVID-19 pandemic and agricultural education: An exploration of challenges faced by teachers. *Natural Sciences Education* 50. https://doi.org/10.1002/nse2.20060.](https://www.zotero.org/google-docs/?JVULmA)

[35. 	Sahu, Pradeep. 2020. Closure of Universities Due to Coronavirus Disease 2019 (COVID-19): Impact on Education and Mental Health of Students and Academic Staff. *Cureus* 12. Cureus. https://doi.org/10.7759/cureus.7541.](https://www.zotero.org/google-docs/?JVULmA)

[36. 	Reynolds, Julie A., Victor Cai, Julia Choi, Sarah Faller, Meghan Hu, Arthi Kozhumam, Jonathan Schwartzman, and Ananya Vohra. 2020. Teaching during a pandemic: Using high-impact writing assignments to balance rigor, engagement, flexibility, and workload. *Ecology and Evolution* 10: 12573–12580. https://doi.org/10.1002/ece3.6776.](https://www.zotero.org/google-docs/?JVULmA)

[37. 	Wan, Shu. 2023. Which Nationals Use Sci-Hub Mostly? *The Serials Librarian* 0. Routledge: 1–5. https://doi.org/10.1080/0361526X.2023.2193613.](https://www.zotero.org/google-docs/?JVULmA)

[38. 	Hoy, Matthew B. 2017. Sci-Hub: What Librarians Should Know and Do about Article Piracy. *Medical Reference Services Quarterly* 36. Routledge: 73–78. https://doi.org/10.1080/02763869.2017.1259918.](https://www.zotero.org/google-docs/?JVULmA)

[39. 	Pastor-Ramon, Elena, Oskia Aguirre, María García-Puente, José María Morán, and Iván Herrera-Peco. 2023. Sci-Hub use among Spanish researchers: Enemy or a learning opportunity for libraries? *Journal of Information Science*. SAGE Publications Ltd: 01655515221142432. https://doi.org/10.1177/01655515221142432.](https://www.zotero.org/google-docs/?JVULmA)

[40. 	Moore, John A. 1984. Science as a Way of Knowing—Evolutionary Biology. *American Zoologist* 24: 467–534. https://doi.org/10.1093/icb/24.2.467.](https://www.zotero.org/google-docs/?JVULmA)



#| end

```Unknown element type at this position: UNSUPPORTED```# Supplementary information




| **Title**                                                                                                     | Journal Club as a Teaching-Learning Strategy: A Case for Plant Genetics Lectures During the COVID-19 Pandemic  |




```Unknown element type at this position: UNSUPPORTED```**Supplementary Table 1**

**Table S1:** Essay evaluation rubric for the journal club implemented in the plant genetics lectures.




| **Criterios**                                                                                                                                                                                                                                                                                                                          | **Puntaje**                                                                                                                                                                                                                                                                                                                            | **Ausente**                                                                                                                                                                                                                                                                                                                            | **Regular**                                                                                                                                                                                                                                                                                                                            | **Bueno**                                                                                                                                                                                                                                                                                                                              | **Excelente**                                                                                                                                                                                                                                                                                                                          | **Descripción**                                                                                                                                                                                                                                                                                                                         |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| **Puntualidad**                                                                                                                                                                                                                                                                                                                        | 0.0                                                                                                                                                                                                                                                                                                                                    | -5.0                                                                                                                                                                                                                                                                                                                                   |                                                                                                                                                                                                                                                                                                                                        |                                                                                                                                                                                                                                                                                                                                        | 0.0                                                                                                                                                                                                                                                                                                                                    | - Entrega de trabajos dentro del plazo asignado.                                                                                                                                                                                                                                                                                        |
| **Introducción**                                                                                                                                                                                                                                                                                                                       | 3.0                                                                                                                                                                                                                                                                                                                                    | 0.0                                                                                                                                                                                                                                                                                                                                    | 1.0                                                                                                                                                                                                                                                                                                                                    | 2.0                                                                                                                                                                                                                                                                                                                                    | 3.0                                                                                                                                                                                                                                                                                                                                    | - Introducción con los objetivos y/o hipótesis de la lectura (máximo 300 palabras).- Texto escrito en un solo párrafo, separando los temas por punto seguido.                                                                                                                                                                           |
| **Resumen**                                                                                                                                                                                                                                                                                                                            | 4.0                                                                                                                                                                                                                                                                                                                                    | 1.0                                                                                                                                                                                                                                                                                                                                    | 2.0                                                                                                                                                                                                                                                                                                                                    | 3.0                                                                                                                                                                                                                                                                                                                                    | 4.0                                                                                                                                                                                                                                                                                                                                    | - Resumen con los puntos más importantes señalados en el artículo.                                                                                                                                                                                                                                                                      |
| **Discusiones**                                                                                                                                                                                                                                                                                                                        | 4.0                                                                                                                                                                                                                                                                                                                                    | 1.0                                                                                                                                                                                                                                                                                                                                    | 2.0                                                                                                                                                                                                                                                                                                                                    | 3.0                                                                                                                                                                                                                                                                                                                                    | 4.0                                                                                                                                                                                                                                                                                                                                    | - Crítica de la lectura, relacionándolo con los saberes previos, opiniones y temas tratados en clases.- Incluir como mínimo una cita por cada integrante.                                                                                                                                                                               |
| **Conclusiones**                                                                                                                                                                                                                                                                                                                       | 3.0                                                                                                                                                                                                                                                                                                                                    | 0.0                                                                                                                                                                                                                                                                                                                                    | 1.0                                                                                                                                                                                                                                                                                                                                    | 2.0                                                                                                                                                                                                                                                                                                                                    | 3.0                                                                                                                                                                                                                                                                                                                                    | - Escribir como texto corrido separadas por punto seguido respondiendo los objetivos (máximo 300 palabras).                                                                                                                                                                                                                             |
| **Referencias**                                                                                                                                                                                                                                                                                                                        | 2.0                                                                                                                                                                                                                                                                                                                                    | 0.0                                                                                                                                                                                                                                                                                                                                    | 1.0                                                                                                                                                                                                                                                                                                                                    | 1.5                                                                                                                                                                                                                                                                                                                                    | 2.0                                                                                                                                                                                                                                                                                                                                    | - Se recomienda usar Zotero para el manejo de referencias.- La referencias deben estar completas: autor, título y año.- NO colocar las citas y referencias toda escrita en mayúsculas.                                                                                                                                                  |
| **Formato**                                                                                                                                                                                                                                                                                                                            | 4.0                                                                                                                                                                                                                                                                                                                                    | 1.0                                                                                                                                                                                                                                                                                                                                    | 2.0                                                                                                                                                                                                                                                                                                                                    | 3.0                                                                                                                                                                                                                                                                                                                                    | 4.0                                                                                                                                                                                                                                                                                                                                    | > Formato:- Usar el formato del American Psychological Association (APA).- Fuente: Times New Roman- Tamaño: 12- Interlineado: 1.15- Texto: justificado- Páginas: máximo 4 páginas numeradas> Recomendaciones:- NO usar viñetas en el documento.- Uso correcto de la gramática: nombres científicos, mayúsculas y signos de puntuación.  |






```Unknown element type at this position: UNSUPPORTED```Dr. Claire Major

Editor-in-Chief

Innovative Higher Education		

Dear Editor,

I hereby enclose the manuscript entitled "Journal Club as a Teaching-Learning Strategy: A Case for Plant Genetics Lectures During the COVID-19 Pandemic" by Flavio Lozano et al. to be considered for publication in Innovative Higher Education.

The implementation of a learning-teaching methodology denominated “Journal Club” in plant genetics lectures was evaluated. The application of the methodology was developed during two academic semesters (i.e., one year) for five sections during the virtualization process due to the COVID-19 pandemic. There was an increase in both the critical thinking and writing skills of the participants. More than 80% of the participants were in favor of this “Journal Club” approach and considered it relevant to their professional education.

We think this manuscript is suitable for publication as the research reflects the aims and scope of your journal. The manuscript has not been published and is not under consideration for publication elsewhere. All authors have approved the manuscript and agree with its submission.

Yours sincerely,



Flavio Lozano-Isla

Corresponding author





---

